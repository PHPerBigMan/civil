# semantic
微信SDK 语义理解模块
