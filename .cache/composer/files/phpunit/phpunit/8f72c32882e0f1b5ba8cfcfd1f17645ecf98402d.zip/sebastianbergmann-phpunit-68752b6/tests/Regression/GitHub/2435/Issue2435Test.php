<?php

/**
 * @group
 */
class Issue2435Test extends PHPUnit_Framework_TestCase
{
    public function testOne()
    {
        $this->assertTrue(true);
    }
}
