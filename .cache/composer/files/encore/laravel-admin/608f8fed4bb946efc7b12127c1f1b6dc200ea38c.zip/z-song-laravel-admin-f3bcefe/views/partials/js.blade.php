@foreach($js as $j)
<script src="{{ asset ("$j") }}"></script>
@endforeach